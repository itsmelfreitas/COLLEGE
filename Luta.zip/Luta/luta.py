from abc import ABC

class Lutador(ABC):
    nome : str
    energia : float
    
    def __init__(self, nome : str, energia : float = 0.0):
        self.nome = nome
        self.energia = 100
        
    def soco(self, oponente : 'Lutador'):
        oponente.energia -= 5.5
        
    def __str__(self):
        return f'Lutador {self.nome} {self.energia:.2f}%'
        
class Boxeador(Lutador):
    def cruzado(self, oponente : Lutador):
        oponente.energia -= 10.2
        
    def gancho(self, oponente : Lutador):
        oponente.energia -= 20.8
    
class Jiujitsu(Lutador):
    def chave_braco(self, oponente : Lutador):
        oponente.energia -= 100
    
class Muay_Thai(Boxeador):
    def chute_alto(self, oponente : Lutador):
        oponente.energia -= 15.4
        
class Taekwondo(Lutador):
    def chute_lateral(self, oponente : 'Lutador'):
        oponente.energia -= 30.4
 
class MMA(Jiujitsu, Muay_Thai, Taekwondo):
    def superman_punch(self, oponente : Lutador):
        oponente.energia -= 53.2
        
    
if __name__ == "__main__":
    maguila = Boxeador("Adilson Maguila")
    tyson = Boxeador("Mike Tyson")
    gracie = Jiujitsu("Royce Gracie")
    prates = Muay_Thai("Carlos Prates")
    
    maguila.soco(tyson)
    tyson.gancho(maguila)
    gracie.chave_braco(prates)
    prates.chute_alto(gracie)
    
    print(maguila)
    print(tyson)
    print(gracie)
    print(prates)