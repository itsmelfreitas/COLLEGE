class Imovel:
    inscricao : int
    area : float
    valor_m2 : float
    
    def __init__(self, i, a, v):
        self.inscricao = i
        self.area = a
        self.valor_m2 = v
        
    def calcular_iptu(self):
        return self.area * self.valor_m2
    
    
class Casa(Imovel):
    area_construida: float
    taxa_construcao:float
    
    def __init__(self, i, a, v, ac, tc):
        super().__init__(i, a, v)
        self.area_construida = ac
        self.taxa_construcao = tc
    
    def calcular_iptu(self):
        return super().calcular_iptu() + (self.area_construida*self.taxa_construcao)