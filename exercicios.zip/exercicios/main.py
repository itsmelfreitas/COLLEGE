from imoveis import *

def exibir_iptu(im):
    print(f"Valor do IPTU {im.calcular_iptu()}")
    
if __name__== "__main__":
    print("SISTEMA DE IPTU")
    
    inscricao = input("Qual a inscricao do imovel? ")
    area = input("Qual a area do imovel? ")
    valor = input("Dirige o valor do metro quadrado: ")
    
    op = input("É um terreno vazio (S/N)")
    
    if op == "S":
        iml = Imovel(int(inscricao), float(area), float(valor))
        exibir_iptu(iml)
        
    else:
        area_cons = input("Qual a área construida? ")
        taxa = input("Qual a taxa de construcao? ")
        cl = Casa(int(inscricao), float(area), float(area), float(valor), float(area_cons), float(taxa))
        exibir_iptu(cl)