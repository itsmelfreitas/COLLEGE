from abc import ABC

class Atleta(ABC):
    nome : str
    idade : int
    peso : float

    def __init__(self, nome : str, idade : int, peso : float):
        self.nome = nome
        self.idade = idade
        self.peso = peso
        
    def aquecer(self):
        return f'{self.nome} aquecendo...'

class Corredor(Atleta):
    def __init__(self, nome, idade, peso):
        super().__init__(nome, idade, peso)
        
    def correr(self):
        return f'{self.nome} correndo...'
    
class Nadador(Atleta):        
    def nadar(self):
        return f'{self.nome} nadando...'
    
class Ciclista(Atleta):
    def pedalar(self):
        return f'{self.nome} pedalando...'
    
class Triatleta(Corredor, Nadador, Ciclista):
    def realizar_maratona(self):
        info = self.aquecer()
        info += self.correr()
        info += self.nadar()
        info += self.pedalar()
        return info