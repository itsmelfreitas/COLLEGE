from atletas import *

if __name__ == "__main__":
    bolt = Corredor("Usain Bolt", 40, 86.2)
    cielo = Nadador("Cesar Cielo", 39, 88.2)
    avancini = Ciclista('Henrique Avancini', 37, 67)
    keller = Triatleta('Fernanda Keller', 68, 56.7)
    
    print(bolt.aquecer())
    print(bolt.correr())
    
    print(cielo.aquecer())
    print(cielo.nadar())
    
    print(avancini.aquecer())
    print(avancini.pedalar())
    
    print(keller.realizar_maratona())